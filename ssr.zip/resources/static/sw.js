importScripts('/_nuxt/workbox.4c4f5ca6.js')

workbox.precaching.precacheAndRoute([
  {
    "url": "/_nuxt/01b18c4e25cab429da2b.js",
    "revision": "56bc216478ab433860147e4ae086e350"
  },
  {
    "url": "/_nuxt/09104114e8a68f007ba9.js",
    "revision": "a0760272fee72793dac976a2927f8058"
  },
  {
    "url": "/_nuxt/0ebef2ce6f9e9ac0c2d1.js",
    "revision": "befb84b771025b895f0993f34ec1fc8e"
  },
  {
    "url": "/_nuxt/123b3bdbe33e0bd8af98.js",
    "revision": "ff62f4258c3cd3871a36dfdde966e87e"
  },
  {
    "url": "/_nuxt/32a6d929470d05e3c0cc.js",
    "revision": "bb276a366344f3605ebd4d09d68ebb58"
  },
  {
    "url": "/_nuxt/396b995e39969d50fbb0.js",
    "revision": "dab9ff528f20dc9edd926ed6e8541ca4"
  },
  {
    "url": "/_nuxt/4d6880934088117390c3.js",
    "revision": "57d9bc2b3e2c1f34b3a2b4e42a7efbe6"
  },
  {
    "url": "/_nuxt/543246a11ed084e7698c.js",
    "revision": "8a580fa6395fa785cb17db4520f537e1"
  },
  {
    "url": "/_nuxt/56c3ee6e916ee15e1e46.js",
    "revision": "255fca48ff5de54d1c0d3bea6bb81cbf"
  },
  {
    "url": "/_nuxt/68ce2020a37aa5722f82.js",
    "revision": "b8887051f06a9547437a9cff7885de81"
  },
  {
    "url": "/_nuxt/6ae9ba182381c2c473d0.js",
    "revision": "ae7e682ad8e1b633b89a3926e091e64f"
  },
  {
    "url": "/_nuxt/6c64838ea185b6ab4943.js",
    "revision": "e0a3c5750a0ddbb398ed4a15d906956f"
  },
  {
    "url": "/_nuxt/7e5fcd39d79f8be58159.js",
    "revision": "630603bbcb80142f4110b501af921e97"
  },
  {
    "url": "/_nuxt/92dc9d0ba125b9bb253d.js",
    "revision": "4ff1ea3238ff02c7249ade3ab699b435"
  },
  {
    "url": "/_nuxt/9459c1881b307917fff7.js",
    "revision": "0c11c20e39e4fd9b02d460e3250b02c6"
  },
  {
    "url": "/_nuxt/a6535a92bf3910b60b3e.js",
    "revision": "8320d8c43c09fa3ea65a8827992ebb62"
  },
  {
    "url": "/_nuxt/a8fc159a670cc9909697.js",
    "revision": "4cb05eea9a9e84023e2d899ec4c05ee3"
  },
  {
    "url": "/_nuxt/a90adab2d53bc31af346.js",
    "revision": "3559c62e1472686312282e2189d74963"
  },
  {
    "url": "/_nuxt/b9bed2b57be068a1a4a5.js",
    "revision": "0173eecce2e3e7b3137547c9b2d003bd"
  },
  {
    "url": "/_nuxt/e9ddd464136898125fc2.js",
    "revision": "b9dd171d50c53c0dd636ce2a2eefc1c3"
  },
  {
    "url": "/_nuxt/ea7bf1be51478ea489b4.js",
    "revision": "9bf332e59510c21c41725c1ed726360e"
  },
  {
    "url": "/_nuxt/f08e4f48b4822c0be44d.js",
    "revision": "57ef989ce65f988576c0c654a125e3fd"
  },
  {
    "url": "/_nuxt/f7e817af59735ad4b4a4.js",
    "revision": "0fbcd1fbd96ac8623be2837f504b2d26"
  },
  {
    "url": "/_nuxt/f9ca2adda577f786dab6.js",
    "revision": "3be9e59a50a4a63088455f903e759f2e"
  }
], {
  "cacheId": "resaa",
  "directoryIndex": "/",
  "cleanUrls": false
})

workbox.clientsClaim()
workbox.skipWaiting()

workbox.routing.registerRoute(new RegExp('/_nuxt/.*'), workbox.strategies.cacheFirst({}), 'GET')

workbox.routing.registerRoute(new RegExp('/.*'), workbox.strategies.networkFirst({}), 'GET')
