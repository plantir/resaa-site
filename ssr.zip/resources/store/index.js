export const state = () => ({
  sitekey: process.env.RECAPTCHA_SITEKEY,
})
export const strict = false
