<template>
  <div class="telegram-section-patients-container">
    <div class="content">
      <div class="telegram-title">رِسا در شبکه های اجتماعی</div>
      <div class="telegram-description">
        از طریق کانال
        <b>تلگرام</b>
        و
        <b>اینستاگرام</b>
        با
        <b>رِسا</b>
        در ارتباط باشید
      </div>
      <div class="link-wrapper">
        <a href="https://www.instagram.com/resaanet/" target="_blank" class="link">
          <i class="fa fa-instagram"></i>
          resaa.medical
        </a>
        <a href="https://t.me/pezeshkepasokhgoo " target="_blank" class="link">
          <i class="fa fa-telegram"></i>
          @pezeshkepasokhgoo
        </a>
      </div>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped>
.telegram-section-patients-container {
  direction: rtl;
  min-height: 200px;
  // background-color: white;
  background-image: url("social-networks.jpg");
  background-size: contain;
  background-position-x: left;
  background-position-y: center;
  background-repeat: no-repeat;
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding-right: 150px;
  overflow: hidden;
  @include respond-to(xl) {
    padding-right: 50px;
  }
  @include respond-to(lg) {
    padding-right: 10px;
  }
  // @include respond-to(md) {
  //   background-image: url("social-networks-m.jpg");
  // }
}

.telegram-title {
  color: #27d3df;
  font-size: 2.375rem;
  font-weight: 500;
  margin-bottom: 20px;
}

.telegram-description {
  margin-bottom: 30px;
  color: #777590;
  font-size: 1.275rem;
}
.link-wrapper {
  display: flex;
  justify-content: space-between;
  width: 320px;
}
.link {
  cursor: pointer;
  color: #aaa;
  i {
    color: #27d3df;
  }
}

@include respond-to(md) {
  .telegram-section-patients-container {
    background-image: url("social-networks-m.jpg");
    padding: 0;
    align-items: center;
    padding-left: 90px;
    padding-right: 30px;
    background-size: cover;
    > div {
      display: flex;
      flex-direction: column;
      width: 100%;
    }
  }
  .link-wrapper {
    flex-direction: column;
  }
  .link {
    color: #fff;
    i {
      color: #fff;
      margin-left: 6px;
    }
    + .link {
      margin-top: 4px;
    }
  }

  .telegram-title {
    font-size: 1.875rem !important;
  }

  .telegram-button {
    background-color: white;
    color: #2ba3e5;
  }

  .telegram-description {
    color: white;
    font-size: 1.375rem;
    text-align: justify;
    line-height: 2.375rem;
    // b {
    //   font-weight: 600;
    // }
  }
}
</style>
