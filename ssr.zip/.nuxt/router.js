import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'

const _1b688097 = () => interopDefault(import('..\\resources\\pages\\about.vue' /* webpackChunkName: "pages_about" */))
const _5389409a = () => interopDefault(import('..\\resources\\pages\\charge.vue' /* webpackChunkName: "pages_charge" */))
const _794d32d1 = () => interopDefault(import('..\\resources\\pages\\contact-us.vue' /* webpackChunkName: "pages_contact-us" */))
const _0c63e284 = () => interopDefault(import('..\\resources\\pages\\doctors\\index.vue' /* webpackChunkName: "pages_doctors_index" */))
const _083cdfc0 = () => interopDefault(import('..\\resources\\pages\\faq.vue' /* webpackChunkName: "pages_faq" */))
const _3cf39692 = () => interopDefault(import('..\\resources\\pages\\privacy.vue' /* webpackChunkName: "pages_privacy" */))
const _e10daa6e = () => interopDefault(import('..\\resources\\pages\\doctors\\landing.vue' /* webpackChunkName: "pages_doctors_landing" */))
const _53e8f4ca = () => interopDefault(import('..\\resources\\pages\\doctors\\login.vue' /* webpackChunkName: "pages_doctors_login" */))
const _6521e961 = () => interopDefault(import('..\\resources\\pages\\doctors\\register.vue' /* webpackChunkName: "pages_doctors_register" */))
const _6cdece98 = () => interopDefault(import('..\\resources\\pages\\patient\\landing.vue' /* webpackChunkName: "pages_patient_landing" */))
const _3cd5d12a = () => interopDefault(import('..\\resources\\pages\\patient\\login.vue' /* webpackChunkName: "pages_patient_login" */))
const _59d3052a = () => interopDefault(import('..\\resources\\pages\\patient\\profile.vue' /* webpackChunkName: "pages_patient_profile" */))
const _3470bf72 = () => interopDefault(import('..\\resources\\pages\\patient\\register.vue' /* webpackChunkName: "pages_patient_register" */))
const _0dd0b5ec = () => interopDefault(import('..\\resources\\pages\\doctors\\_id.vue' /* webpackChunkName: "pages_doctors__id" */))
const _3b205b5c = () => interopDefault(import('..\\resources\\pages\\index.vue' /* webpackChunkName: "pages_index" */))

Vue.use(Router)

if (process.client) {
  window.history.scrollRestoration = 'manual'
}
const scrollBehavior = function (to, from, savedPosition) {
  // if the returned position is falsy or an empty object,
  // will retain current scroll position.
  let position = false

  // if no children detected and scrollToTop is not explicitly disabled
  if (
    to.matched.length < 2 &&
    to.matched.every(r => r.components.default.options.scrollToTop !== false)
  ) {
    // scroll to the top of the page
    position = { x: 0, y: 0 }
  } else if (to.matched.some(r => r.components.default.options.scrollToTop)) {
    // if one of the children has scrollToTop option set to true
    position = { x: 0, y: 0 }
  }

  // savedPosition is only available for popstate navigations (back button)
  if (savedPosition) {
    position = savedPosition
  }

  return new Promise((resolve) => {
    // wait for the out transition to complete (if necessary)
    window.$nuxt.$once('triggerScroll', () => {
      // coords will be used if no selector is provided,
      // or if the selector didn't match any element.
      if (to.hash) {
        let hash = to.hash
        // CSS.escape() is not supported with IE and Edge.
        if (typeof window.CSS !== 'undefined' && typeof window.CSS.escape !== 'undefined') {
          hash = '#' + window.CSS.escape(hash.substr(1))
        }
        try {
          if (document.querySelector(hash)) {
            // scroll to anchor by returning the selector
            position = { selector: hash }
          }
        } catch (e) {
          console.warn('Failed to save scroll position. Please add CSS.escape() polyfill (https://github.com/mathiasbynens/CSS.escape).')
        }
      }
      resolve(position)
    })
  })
}

export function createRouter() {
  return new Router({
    mode: 'history',
    base: '/',
    linkActiveClass: 'nuxt-link-active',
    linkExactActiveClass: 'nuxt-link-exact-active',
    scrollBehavior,

    routes: [{
      path: "/about",
      component: _1b688097,
      name: "about"
    }, {
      path: "/charge",
      component: _5389409a,
      name: "charge"
    }, {
      path: "/contact-us",
      component: _794d32d1,
      name: "contact-us"
    }, {
      path: "/doctors",
      component: _0c63e284,
      name: "doctors"
    }, {
      path: "/faq",
      component: _083cdfc0,
      name: "faq"
    }, {
      path: "/privacy",
      component: _3cf39692,
      name: "privacy"
    }, {
      path: "/doctors/landing",
      component: _e10daa6e,
      name: "doctors-landing"
    }, {
      path: "/doctors/login",
      component: _53e8f4ca,
      name: "doctors-login"
    }, {
      path: "/doctors/register",
      component: _6521e961,
      name: "doctors-register"
    }, {
      path: "/patient/landing",
      component: _6cdece98,
      name: "patient-landing"
    }, {
      path: "/patient/login",
      component: _3cd5d12a,
      name: "patient-login"
    }, {
      path: "/patient/profile",
      component: _59d3052a,
      name: "patient-profile"
    }, {
      path: "/patient/register",
      component: _3470bf72,
      name: "patient-register"
    }, {
      path: "/doctors/:id",
      component: _0dd0b5ec,
      name: "doctors-id"
    }, {
      path: "/",
      component: _3b205b5c,
      name: "index"
    }],

    fallback: false
  })
}
