import Vue from 'vue'
import VueAnalytics from 'vue-analytics'

export default async function ({ app: { router } }) {
  const options = {"dev":true,"debug":{},"id":"UA-135235561-1"}

  Vue.use(VueAnalytics, {...{ router }, ...options})
}
