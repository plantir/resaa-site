import Vue from 'vue';
import VueRecaptcha from "vue-recaptcha";
Vue.component('VueRecaptcha', VueRecaptcha);
